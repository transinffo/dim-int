<?php
// Heading
$_['heading_title'] = 'Recently Viewed';
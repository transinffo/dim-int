<?php
// Text
$_['text_all'] = 'Показати усі';
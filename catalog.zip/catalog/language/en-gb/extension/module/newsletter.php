<?php
// Heading
$_['message_exist']     = 'Ви вже підписані';
$_['subscribe']     = 'Ви підписались';
$_['entry_email']     = 'Ваш email';

<?php
class ControllerExtensionModuleHreflang extends Controller
{
    /**
     * @param string $route
     * @param $data
     * mixing their data
     * Call to the event: 'catalog/view/common/header/before'->'extension/module/hreflang/joinLinks'
     */
    public function joinLinks($route = '', &$data)
    {
        $data['hreflangs'] = $this->constructHreflangs();
    }

    /**
     * @return array
     */
    private function constructHreflangs()
    {
        // список языков
        if (!isset($this->session->data['languages'])) {
            $this->load->model('localisation/language');

            $this->session->data['languages'] = $this->model_localisation_language->getLanguages();
        }

        $links = array();

        $this->load->model('extension/module/hreflang');

        $queriesToArray = $this->queriesToArray();

        $rows = array();

        // path
        if (count($queriesToArray)) { // if isset($this->request->get['_route_'])
            $rows = $this->model_extension_module_hreflang->getPathKeywords($queriesToArray);
        }

        // adaptor for extensions
        if (!count($rows) && isset($this->request->get['_route_'])) {
            $rows = $this->model_extension_module_hreflang->extendKeywords($this->request->get['_route_']);
        }

        //
        if (!count($rows) && !count($queriesToArray) && $this->request->get['route'] == 'common/home') {
            $rows = $this->model_extension_module_hreflang->getPathKeywords(array('common/home'));
        }

        foreach ($rows as $row) {
            $links[$row['language_id']][$row['query']] = (string)$row['keyword'];
        }

        $path_length = 0;

        //
        foreach ($links as $link) {
            if (count($link) > (int)$path_length)
                $path_length = count($link);
        }

        // Get setting module
        $config_xdefault = array();

        $config_xdefault['code'] = $this->config->get('hreflangs_xdefault');

        // Fix No setting
        if (!isset($config_xdefault['code']) || $config_xdefault['code'] == 'default') {
            $config_xdefault = $this->defaultLanguage();
        }

        //
        $hreflangs = array();

        foreach ($this->session->data['languages'] as $language) {
            if (!isset($links[$language['language_id']])
                || !$code = $this->languageCode($language['code']))
                continue;
            if (count($links[$language['language_id']]) != $path_length)
                continue;

            if (isset($config_xdefault['code']) && $language['code'] === $config_xdefault['code']) {
                $hreflangs['x-default'] = $this->server() . $this->implodeUrl($links[$language['language_id']]) . $this->postfix();
            }

            $hreflangs[$code] = $this->server() . $this->implodeUrl($links[$language['language_id']]) . $this->postfix();
        }

        return $hreflangs;
    }

    /**
     * @param $code
     * @return string
     */
    private function languageCode($code)
    {
        if ($this->session->data['languages'] && $this->config->get('hreflangs_codeform') && $this->config->get('hreflangs_codeform') !== 'code' && isset($this->session->data['languages'][$code]['locale'])) {
            $explode = explode(',', $this->session->data['languages'][$code]['locale']);

            $code = $explode[0];
        }

        return (string)$code;
    }

    /**
     * @return array
     */
    private function defaultLanguage()
    {
        $default = array(
            'code' => 'en-gb',
            'locale' => 'en-GB'
        );

        $config_language = $this->config->get('config_language');

        if (isset($config_language)) {
            $default = array(
                'code' => $config_language,
                'locale' => $this->languageCode($config_language)
            );
        }

        return (array)$default;
    }

    /**
     * @return string
     */
    private function server()
    {
        if (isset($this->request->server['HTTPS'])
            && (($this->request->server['HTTPS'] == 'on')
                || ($this->request->server['HTTPS'] == '1'))) {
            return (string)$this->config->get('config_ssl');
        }

        return (string)$this->config->get('config_url');
    }

    /**
     * @return string
     */
    private function postfix()
    {
        if (!$this->config->get('config_page_postfix')) return '';

        // TODO
        if (!isset($this->request->get['product_id']) && isset($this->request->get['route']) && $this->request->get['route'] !== 'information/information') return '';

        return (string)$this->config->get('config_page_postfix');
    }

    /**
     * @param array $explode
     * @return string
     */
    private function implodeUrl($explode = array())
    {
        $implode = '';

        $implode = implode('/', $explode);

        return $implode;
    }

    /**
     * @return array
     */
    private function queriesToArray()
    {
        $queries = array();

        if (isset($this->request->get['path'])) {
            $explode = explode('_', $this->request->get['path']);

            foreach ($explode as $item) {
                $queries[] = 'category_id=' . (string)$item;
            }
        }

        if (isset($this->request->get['product_id'])) {
            $queries[] = 'product_id=' . $this->request->get['product_id'];
        } elseif (isset($this->request->get['manufacturer_id'])) {
            $queries[] = 'manufacturer_id=' . $this->request->get['manufacturer_id'];
        } elseif (isset($this->request->get['information_id'])) {
            $queries[] = 'information_id=' . $this->request->get['information_id'];
        } elseif (isset($this->request->get['blog_category_id'])) {
            $queries[] = 'blog_category_id' . $this->request->get['blog_category_id'];
        }
        // TODO

        return $queries;
    }
}

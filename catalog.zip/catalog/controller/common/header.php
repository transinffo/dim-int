<?php
class ControllerCommonHeader extends Controller {
	public function index() {
		
		// HTML Бегушая строка
$this->load->model('setting/module');
$begstroka_links = $this->model_setting_module->getModule(68);
$data['begstroka_links'] = array(
	'title'  => $begstroka_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($begstroka_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);
		
		// Analytics
		$this->load->model('setting/extension');

		$data['analytics'] = array();

		$analytics = $this->model_setting_extension->getExtensions('analytics');

		foreach ($analytics as $analytic) {
			if ($this->config->get('analytics_' . $analytic['code'] . '_status')) {
				$data['analytics'][] = $this->load->controller('extension/analytics/' . $analytic['code'], $this->config->get('analytics_' . $analytic['code'] . '_status'));
			}
		}

		if ($this->request->server['HTTPS']) {
			$server = $this->config->get('config_ssl');
		} else {
			$server = $this->config->get('config_url');
		}

		if (is_file(DIR_IMAGE . $this->config->get('config_icon'))) {
			$this->document->addLink($server . 'image/' . $this->config->get('config_icon'), 'icon');
		}

		$data['title'] = $this->document->getTitle();

		$data['base'] = $server;
		$data['description'] = $this->document->getDescription();
		$data['keywords'] = $this->document->getKeywords();
		$data['links'] = $this->document->getLinks();
		$data['styles'] = $this->document->getStyles();
		$data['scripts'] = $this->document->getScripts('header');
		$data['lang'] = $this->language->get('code');
		$data['direction'] = $this->language->get('direction');
        $data['telephone'] = $this->config->get('config_telephone');
		$data['name'] = $this->config->get('config_name');

		if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
			$data['logo'] = $server . 'image/' . $this->config->get('config_logo');
		} else {
			$data['logo'] = '';
		}

		$this->load->language('common/header');

		// Wishlist
		if ($this->customer->isLogged()) {
			$this->load->model('account/wishlist');

			$data['text_wishlist'] = sprintf($this->language->get('text_wishlist'), $this->model_account_wishlist->getTotalWishlist());
		} else {
			$data['text_wishlist'] = sprintf($this->language->get('text_wishlist'), (isset($this->session->data['wishlist']) ? count($this->session->data['wishlist']) : 0));
		}

		$data['text_logged'] = sprintf($this->language->get('text_logged'), $this->url->link('account/account', '', true), $this->customer->getFirstName(), $this->url->link('account/logout', '', true));
		
		$data['home'] = $this->url->link('common/home');
		$data['wishlist'] = $this->url->link('account/wishlist', '', true);
		$data['logged'] = $this->customer->isLogged();
		$data['account'] = $this->url->link('account/account', '', true);
		$data['register'] = $this->url->link('account/register', '', true);
		$data['login'] = $this->url->link('account/login', '', true);
		$data['order'] = $this->url->link('account/order', '', true);
		$data['transaction'] = $this->url->link('account/transaction', '', true);
		$data['download'] = $this->url->link('account/download', '', true);
		$data['logout'] = $this->url->link('account/logout', '', true);
		$data['shopping_cart'] = $this->url->link('checkout/cart');
		$data['checkout'] = $this->url->link('checkout/checkout', '', true);
		$data['contact'] = $this->url->link('information/contact');
		$data['telephone'] = $this->config->get('config_telephone');


		$data['route'] = isset($this->request->get['route']) ? $this->request->get['route'] : 'common/home';

		
		$data['language'] = $this->load->controller('common/language');
		$data['currency'] = $this->load->controller('common/currency');
		$data['search'] = $this->load->controller('common/search');
		$data['cart'] = $this->load->controller('common/cart');
		$data['menu'] = $this->load->controller('common/menu');
        $data['home_url'] = $_SERVER['REQUEST_URI'];



		$data['adres_ua'] = html_entity_decode($this->config->get('config_address_multi')[1], ENT_QUOTES, 'UTF-8');
		$data['adres_ru'] = html_entity_decode($this->config->get('config_address_multi')[2], ENT_QUOTES, 'UTF-8'); 






		 // hreflang ----------------------------------------------------------------------------

		// Получаем текущий путь без GET параметров
			$current_path = strtok($_SERVER['REQUEST_URI'], '?'); // Убираем GET параметры
			$current_path = rtrim($current_path, '/'); // Убираем слеш в конце, если есть

			// Настроим языковые коды и префиксы
			$default_language_code = 'uk-ua';
			$alternate_languages = [
			    'uk-ua' => '',
			    'ru-ru' => '/ru'
			];

			// Получаем текущий язык
			$current_language_code = $this->session->data['language'] ?? $default_language_code;

			// Проверка, если мы на главной странице для русского языка
			if ($current_language_code === 'ru-ru' && $current_path === '/ru') {
			    $current_path = '';  // Главная страница на русском
			}

			// Если мы на русской версии страницы, удаляем /ru из пути
			if ($current_language_code === 'ru-ru' && strpos($current_path, '/ru') === 0) {
			    $current_path = substr($current_path, 3); // Удаляем "/ru"
			}

			// Генерация hreflang ссылок
			$hreflang_links = [];

			// Для каждого языка генерируем ссылки
			foreach ($alternate_languages as $code => $prefix) {
			    $hreflang_url = rtrim(HTTP_SERVER, '/') . $prefix . $current_path;
			    $hreflang_code = ($code === 'uk-ua') ? 'uk' : 'ru';
			    $hreflang_links[] = '<link rel="alternate" href="' . $hreflang_url . '" hreflang="' . $hreflang_code . '">';
			}

			// Добавляем x-default для украинской версии
			$hreflang_links[] = '<link rel="alternate" href="' . rtrim(HTTP_SERVER, '/') . $current_path . '" hreflang="x-default">';

			$data['hreflang_links'] = implode("\n", $hreflang_links);



		// hreflang ----------------------------------------------------------------------------

   

		return $this->load->view('common/header_new', $data);


		// if (isset($this->request->get['new_header']) && $this->request->get['new_header'] == '1') {
		//     return $this->load->view('common/header_new', $data);
		// } else {
		//     return $this->load->view('common/header', $data);
		// }

	}



}

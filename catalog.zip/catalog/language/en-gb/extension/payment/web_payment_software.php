<?php
// Text
$_['text_title']           = 'Credit Card / Debit Card (Web Payment Software)';
$_['text_credit_card']     = 'Credit Card Details';

// Entry
$_['entry_cc_owner']       = 'Card Owner';
$_['entry_cc_number']      = 'Card Number';
$_['entry_cc_expire_date'] = 'Card Expiry Date';
$_['entry_cc_cvv2']        = 'Card Security Code (CVV2)';
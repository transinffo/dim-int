<?php
// Text
$_['text_title'] = 'Львів';
$_['text_description'] = 'Кур’єрська доставка по Львові';
$_['my_textdostavka']       = 'ДОСТАВКА ЗА ТАРИФАМИ ПЕРЕВІЗНИКА';
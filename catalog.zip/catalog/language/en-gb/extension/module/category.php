<?php
// Heading
$_['heading_title'] = 'Категорії';
$_['heading_title1'] = 'Популярні категорії';
$_['heading_title2'] = 'Двері';
$_['heading_title3'] = 'Сантехніка';
$_['heading_title4'] = 'Меблі';
$_['heading_title5'] = 'Покриття для підлоги';
$_['heading_title6'] = 'Детальніше';

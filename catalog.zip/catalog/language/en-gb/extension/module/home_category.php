<?php
// Heading
$_['heading_title'] = 'Home category';

// Text
$_['text_tax']      = 'Ex Tax:';
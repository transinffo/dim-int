<?php
// Heading
$_['heading_title'] = 'Салони';

// Text
$_['text_tax'] = 'Без ПДВ:';
$_['text_map'] = 'На карті';
$_['text_price'] = 'Ціна';

<?php
// Heading
$_['heading_title'] = 'Акції';

// Text
$_['text_tax'] = 'Без ПДВ:';
$_['text_instock'] = 'В наявності';
$_['text_outstock'] = 'Відсутній';
$_['text_link_cat'] = 'Каталог';
$_['text_price'] = 'Ціна';
<?php
class ControllerCommonHome extends Controller {
	public function index() {
		
		// HTML Наши преимущества - Блок 1		
$this->load->model('setting/module');
$perevagi53_links = $this->model_setting_module->getModule(53);
$data['perevagi53_links'] = array(
	'title'  => $perevagi53_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi53_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);
	// HTML Наши преимущества - Блок 2		
$this->load->model('setting/module');
$perevagi62_links = $this->model_setting_module->getModule(62);
$data['perevagi62_links'] = array(
	'title'  => $perevagi62_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi62_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);
	// HTML Наши преимущества - Блок 3		
$this->load->model('setting/module');
$perevagi63_links = $this->model_setting_module->getModule(63);
$data['perevagi63_links'] = array(
	'title'  => $perevagi63_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi63_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);

	// HTML Наши преимущества - Текстовый блок 1		
$this->load->model('setting/module');
$perevagi64_links = $this->model_setting_module->getModule(64);
$data['perevagi64_links'] = array(
	'title'  => $perevagi64_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi64_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);

	// HTML Наши преимущества - Текстовый блок 5	
$this->load->model('setting/module');
$perevagi65_links = $this->model_setting_module->getModule(65);
$data['perevagi65_links'] = array(
	'title'  => $perevagi65_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi65_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);

	// HTML Наши преимущества - Текстовый блок 3	
$this->load->model('setting/module');
$perevagi66_links = $this->model_setting_module->getModule(66);
$data['perevagi66_links'] = array(
	'title'  => $perevagi66_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi66_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);

	// HTML Наши преимущества - Текстовый блок 4	
$this->load->model('setting/module');
$perevagi67_links = $this->model_setting_module->getModule(67);
$data['perevagi67_links'] = array(
	'title'  => $perevagi67_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi67_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);

// HTML Блок баннер под меню
$this->load->model('setting/module');
$perevagi72_links = $this->model_setting_module->getModule(72);
$data['perevagi72_links'] = array(
	'title'  => $perevagi72_links['module_description'][$this->config->get('config_language_id')]['title'],
	'description'  => utf8_substr(html_entity_decode($perevagi72_links['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8'), 0)
);
		
		$this->document->setTitle($this->config->get('config_meta_title'));
		$this->document->setDescription($this->config->get('config_meta_description'));
		$this->document->setKeywords($this->config->get('config_meta_keyword'));

		if (isset($this->request->get['route'])) {
			$this->document->addLink($this->config->get('config_url'), 'canonical');
		}

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

        //данные для микроразметки ---------------------------------------------------------------

        $home_url = $this->config->get('config_url');
        $data['store'] = $this->config->get('config_name');
        $data['logo'] = $home_url."image/".$this->config->get('config_image');
        $data['telephone'] = $this->config->get('config_telephone');
        $data['site_url'] = $this->url->link('common/home', '', true);

		//file_put_contents(DIR_LOGS . 'error.log', print_r($data, true), FILE_APPEND);
		//данные для микроразметки ---------------------------------------------------------------


		/*Add menu line*/
        $data['menu'] = $this->load->controller('common/menu');
        /*end menu line*/
		$this->response->setOutput($this->load->view('common/home', $data));
	}
}

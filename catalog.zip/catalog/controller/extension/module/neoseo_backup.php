<?php
/*
 * @ https://EasyToYou.eu - IonCube v10 Decoder Online
 * @ PHP 5.6
 * @ Decoder version: 1.0.4
 * @ Release: 02/06/2020
 *
 * @ ZendGuard Decoder PHP 5.6
 */

require_once DIR_SYSTEM . "/engine/neoseo_controller.php";
class ControllerExtensionModuleNeoSeoBackup extends NeoSeoController
{
    public function drive()
    {
        if (isset($_GET["code"])) {
            $this->load->model("tool/neoseo_backup");
            $this->language->load("extension/module/neoseo_backup");
            $answer = $this->model_tool_neoseo_backup->getAccess((int) $_GET["code"]);
            if ($answer) {
                $this->model_tool_neoseo_backup->save_setting($answer);
                echo "<h1>" . $this->language->get("text_grant") . "</h1><h2>" . $this->language->get("text_may_close") . "</h2>";
            } else {
                echo "<h1>" . $this->language->get("text_erorr_grant") . "</h1>";
            }
        } else {
            header("Location: /", true, 307);
        }
    }
}

?>
<?php
// Buttons
$_['button_go_to_checkout']         = 'В кошик';
$_['button_go_back']                = 'Продовжити покупки';
$_['button_save_cart']              = 'Зберегти корзину';
$_['buttom_save_cart_to_email']     = 'Відправити на Email';
$_['buttom_save_cart_to_wishlist']  = 'Зберегти в Закладки';
$_['button_cart_add']               = 'Додати в корзину';
$_['button_carousel_prev']          = '&#8249; Наз';
$_['button_carousel_next']          = 'Впер &#8250;';
$_['button_send_cart']              = 'Відправити';

// Collumns
$_['column_remove']                 = 'Видалити';
$_['column_name']                   = 'Назва товару';
$_['column_model']                  = 'Артикул';
$_['column_image']                  = 'Фото';
$_['column_quantity']               = 'Кількість';
$_['column_price']                  = 'Ціна';
$_['column_total']                  = 'Сума';

// Text
$_['text_to_close']                 = 'Натисніть, щоб закрити вікно';
$_['text_total_bottom']             = 'Загалом';
$_['text_tax']                      = 'ПДВ: ';
$_['text_model']                    = 'Артикул: ';
$_['text_ean']                      = 'EAN: ';
$_['text_jan']                      = 'JAN: ';
$_['text_isbn']                     = 'ISBN: ';
$_['text_mpn']                      = 'MPN: ';
$_['text_location']                 = 'Локація: ';
$_['text_cart_saved']               = 'Корзина збережена: %s';
$_['text_saved_cart']               = 'Корзина збережена: ';
$_['text_instock']                  = 'В наявності';
$_['text_availability']             = 'Наявність: ';
$_['text_points']                   = 'Бонуси: ';
$_['text_cart_weight']              = 'Вага: ';
$_['text_coupon_title']             = 'Використати код купону';
$_['text_voucher_title']            = 'Використати подарунковий сертифікат';
$_['text_shipping_title']           = 'Розрахунок вартості доставки';
$_['text_reward_title_heading']     = 'Використати бонуси (Доступно %s)';
$_['text_help_heading']             = 'Виберіть, якщо у вас є купон на знижку або бали і ви хочете їх використати або хотіли б розрахувати вартість доставки.';
$_['text_shipping_help']            = 'Введіть адресу доставки, щоб отримати передбачувану вартість доставки.';
$_['text_cp_shipping_method']     = 'Будь ласка, виберіть спосіб доставки для цього замовлення.';

// Entry
$_['entry_coupon']                  = 'Введіть код купону тут';
$_['entry_voucher']                 = 'Введіть код сертифікату тут';
$_['entry_reward']                  = 'Бонуси для використання (макс %s)';
$_['entry_country']                 = '-- Виберіть країну --';
$_['entry_zone']                    = '-- Виберіть регіон --';
$_['entry_postcode']                = 'Введіть індекс';

// Success
$_['text_success_send']             = 'Успішно: Операція завершена успішно!';
$_['text_success_coupon']           = 'Успішно: Ваш купон застосований!';
$_['text_success_voucher']          = 'Успішно: Ваш подарунковий сертифікат застосований!';
$_['text_success_shipping']         = 'Успішно: Вартість доставки розрахована!';
$_['text_success_reward']           = 'Успішно: Знижка по бонусним балам зарахована!';

// Error
$_['error_email_send']              = 'E-Mail введено неправильно!';
$_['error_stock']                   = 'Товарів виділених червоним немає в наявності в необхідній кількості!';
$_['error_cp_coupon_empty']       = 'Введіть код купону!';
$_['error_cp_coupon']             = 'Купон недійсний або закінчився термін його дії!';
$_['error_cp_voucher_empty']      = 'Введіть код сертифікату!';
$_['error_cp_voucher']            = 'Подарунковий сертифікат недійсний або його баланс вже використаний!';
$_['error_cp_shipping']           = 'Виберіть спосіб доставки!';
$_['error_cp_postcode']           = 'Поштовий індекс повинен містити від 2 до 10 символів!';
$_['error_cp_country']            = 'Виберіть країну!';
$_['error_cp_zone']               = 'Виберіть регіон!';
$_['error_cp_no_shipping']        = 'Немає способів доставки. Будь ласка, <a href="%s" target="blank">напишіть нам</a> для вирішення проблеми!';
$_['error_cp_reward']             = 'Введіть кількість бонусних балів для використання!';
$_['error_cp_points']             = 'Вам не вистачає %s бонусних балів!';
$_['error_cp_maximum']            = 'Можна використовувати максимально %s балів!';
?>
